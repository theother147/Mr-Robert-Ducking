# Description: Configuration file for the server
class Config:
    HOST = "localhost"
    PORT = 8765
    LOG_LEVEL = "DEBUG"